<?php

use App\Http\Controllers\AuthenController;
use Illuminate\Support\Facades\Route;
use Illuminate\Auth\Middleware\Authenticate;

Route::get('/', function () {
    return view('welcome');
});

Route::middleware('guest')->group(function(){

    Route::get('/register',[AuthenController::class,'Register']);
    Route::post('/register/authenticate',[AuthenController::class,'Store'])->name('register.authenticate');
    Route::post('logon/authenthicate',[AuthenController::class, 'Login'])->name('login');
    Route::post('/login/authenthicate', [AuthenController::class, 'Authen'])->name('login.authenticate');
});

Route::middleware('auth')->group(function(){
    Route::view('/home','home');
    Route::get('/login',[AuthenController::class, 'Logout'])->name('logout');
});

