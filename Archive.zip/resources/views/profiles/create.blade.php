@extends('profiles.layout')
@section('content')
    <div class="card mt-5">
        <h2>Add New Profile</h2>
        <div class="card body">
            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                <a  class="btn btn-primary btn-sm" href="{{ route('profile.index') }}"><i class="fa fa-arrow-left">Back</a>

            </div>
            <form action="{{ route('profiles.store') }}" method="POST" enctype="multipart/form-data">
                @csrf

                <div class="mb-3">
                    <label for="inpurName" class="form=lable"><strong></label>
                        <input
                        type="text"
                        name="name"
                        class="form-control @error('name')is-invalid @enderror"
                        id="inputName"
                        placeholder="Name">
                        @error('name')
                        <div class="form-text text-danger">{{ $me }}</div>


                        @enderror
                    </div>

                    <div class="mb=-3">
                        <label for="inputEmail" class="from=label"><strong>Email</strong></label>
                        <input
                        type="email"
                        class="form-control @error('email') is-invalid @enderror"
                        name="email"
                        id="inputEmail">
                        @error('email')
                        <div class="from-text text-danger">{{ $message }}</div>
                        @enderror
                        </div>

                        <div class="mb-3">
                            <label for="inputmage" class="frome-lable"><strong>Image:</strong></label>
                            <input
                            type="file"
                            >
                        </div>
                        @enderror

                        @enderror"


                    </div>


                        @enderror
                </div>
            </form>
        </div>
    </div>


